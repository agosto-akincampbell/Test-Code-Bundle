# Test Code Bundle

Special code bundle for QA that would show all the display variables and ask for all permissions we allow.

## Code Bundle Capabilities:
1) Display all attributes that the code bundle can get
2) Get geolocation / info from geolocation api and display it
3) Use media api
